To use the Town_Halls_HSIP.lyr layer file, which displays the Town Halls layer 
with the federal Homeland Security Working Group symbology, in ArcGIS you 
must first install the ERS_v2_Infrastructures_S1_sym.ttf True Type font file 
included in this .zip archive.

For reference see http://www.fgdc.gov/HSWG/ref_pages/Infrastructures_ref.htm.
